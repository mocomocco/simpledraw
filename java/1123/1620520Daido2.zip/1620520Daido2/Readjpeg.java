import java.net.*;
import java.io.*;

public class Readjpeg{
    public static void main(String[] args){
	try{
	    URL targetURL =new URL(args[0]);
	    InputStream istream = targetURL.openStream();

	    FileOutputStream fout =new FileOutputStream("cat.jpg");
	    int i;

	    while((i=istream.read())!=-1){
		fout.write(i);
	    }
	    istream.close();
	    fout.close();
	}catch(IOException e){
	    System.out.println(e);
	}
    }

}
